# `Texture-Studio`

[New thread](https://www.burgershot.gg/showthread.php?tid=174), since the previous thread was deleted by your king. 
